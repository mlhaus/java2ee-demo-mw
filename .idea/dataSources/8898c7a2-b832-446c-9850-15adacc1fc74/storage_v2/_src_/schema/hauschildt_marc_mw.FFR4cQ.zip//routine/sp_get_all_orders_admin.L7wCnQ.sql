create
    definer = Java21Tomcat10@`%` procedure sp_get_all_orders_admin()
BEGIN
    SELECT order_num, order_date, orders.cust_id, cust_name
    FROM orders JOIN customers
                     ON orders.cust_id = customers.cust_id;
END;

