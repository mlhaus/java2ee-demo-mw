create
    definer = Java21Tomcat10@`%` procedure sp_get_all_products()
BEGIN
    SELECT prod_id, prod_name, prod_price, prod_desc FROM products;
END;

